console.log(`Elements which are divisible by 5 from 1to 50
`)

let a=1
while (a<=50)
{
  
 if(a%5==0){
 console.log(a);
 }
 
 a++;
 
}